/*function readMore() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("button");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Read more";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Read less";
      moreText.style.display = "inline";
    }
  }
          function closeNav() {
            document.getElementById("sidebar").style.width = "0";
            document.getElementById("sidebarbutton").style.marginLeft = "0";
        }

        function openNav() {
            document.getElementById("sidebar").style.width = "250px";
            document.getElementById("sidebarbutton").style.marginLeft = "250px";
        }
  
  */